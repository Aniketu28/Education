

var courses = [
    {
        id: 0,
        courseBanner: "./Asset/images/c1.png",
        CourseCategories: "Art & Design",
        CoursePrice: "$29.28",
        CourseName: "Basic Fundamentals of Interior & Graphics Design",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 1,
        courseBanner: "./Asset/images/c2.png",
        CourseCategories: "Digital marketing",
        CoursePrice: "Free",
        CourseName: "Increasing Engagement with Instagram & Facebook",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 2,
        courseBanner: "./Asset/images/c3.png",
        CourseCategories: "Drawing",
        CoursePrice: "$72.39",
        CourseName: "Introduction to Color Theory & Basic UI/UX",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 3,
        courseBanner: "./Asset/images/c4.png",
        CourseCategories: "Finance",
        CoursePrice: "$72.39",
        CourseName: "Financial Security Thinking and Principles Theory",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 4,
        courseBanner: "./Asset/images/c5.png",
        CourseCategories: "Graphics",
        CoursePrice: "Free",
        CourseName: "Logo Design: From Concept to Presentation",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 5,
        courseBanner: "./Asset/images/c6.png",
        CourseCategories: "Development",
        CoursePrice: "$29.82",
        CourseName: "Professional Ceramic Moulding for Beginners",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 6,
        courseBanner: "./Asset/images/c1.png",
        CourseCategories: "Art & Design",
        CoursePrice: "$29.28",
        CourseName: "Basic Fundamentals of Interior & Graphics Design",
        CourseDescription: "This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. You will be exposed to principles and strategies, but, more importantly, you will learn how to actually apply these abstract concepts by coding three different websites for three very different audiences. Lorem ipsum is dummy text used in laying out print, graphic or web designs. Lorem ipsum blinding shot chinwag knees.<br> This tutorial will help you learn quickly and thoroughly. Lorem ipsum or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 7,
        courseBanner: "./Asset/images/c2.png",
        CourseCategories: "Digital marketing",
        CoursePrice: "Free",
        CourseName: "Increasing Engagement with Instagram & Facebook",
        CourseDescription: "Learn how to boost engagement on Instagram & Facebook. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in tellus nec orci feugiat sagittis. Duis sollicitudin euismod nisi, id consectetur mauris posuere nec. Aliquam vitae nulla eget nisi eleifend semper. Vestibulum condimentum massa sed ante congue tincidunt. Cras non felis vel nisi dictum feugiat non eget tellus. Donec dapibus mi ut vehicula mollis. Mauris eu elit in felis placerat vestibulum. Ut porta elit ac feugiat lobortis.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 8,
        courseBanner: "./Asset/images/c3.png",
        CourseCategories: "Drawing",
        CoursePrice: "$72.39",
        CourseName: "Introduction to Color Theory & Basic UI/UX",
        CourseDescription: "Get started with color theory and basic UI/UX design principles. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin id volutpat est. Sed eget lectus et augue porttitor commodo. Integer at lectus sed ipsum semper varius. Fusce euismod augue eu purus euismod, in consequat est pharetra. Sed nec justo quis enim eleifend rhoncus non in purus. Maecenas eu semper purus, non vestibulum felis. Nam vel risus eget mi fermentum tempor in vitae urna.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 9,
        courseBanner: "./Asset/images/c4.png",
        CourseCategories: "Finance",
        CoursePrice: "$72.39",
        CourseName: "Financial Security Thinking and Principles Theory",
        CourseDescription: "Learn about financial security thinking and principles theory. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt est ac nisi mattis efficitur. Nullam vitae metus vitae purus elementum tristique. Ut eu tortor condimentum, vestibulum leo ut, luctus ex. Vestibulum at nulla ac sapien accumsan viverra. Suspendisse potenti. Nulla convallis lorem nec turpis elementum fringilla. Curabitur ac leo id elit vehicula malesuada a nec orci.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 10,
        courseBanner: "./Asset/images/c5.png",
        CourseCategories: "Graphics",
        CoursePrice: "Free",
        CourseName: "Logo Design: From Concept to Presentation",
        CourseDescription: "Learn the process of logo design from concept to presentation. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla id sollicitudin lacus. Nullam ac purus in ligula ultricies tincidunt. Duis tincidunt auctor mi, nec pellentesque nisi sodales ac. Nam hendrerit ligula at velit lacinia lacinia. Integer luctus hendrerit purus, vel efficitur sem viverra sit amet. Duis convallis orci id enim iaculis, in ultricies metus vehicula.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    },
    {
        id: 11,
        courseBanner: "./Asset/images/c6.png",
        CourseCategories: "Development",
        CoursePrice: "$29.82",
        CourseName: "Professional Ceramic Moulding for Beginners",
        CourseDescription: "Master ceramic moulding techniques for beginners. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vestibulum tellus vel lorem mollis aliquam. In non enim sit amet nisl aliquam efficitur vitae id dui. Proin id dapibus purus, non maximus lectus. Vestibulum eu libero elit. Aliquam quis tortor eget eros eleifend pharetra vel a urna. Vestibulum vehicula, magna a facilisis rutrum, mi eros tempus sapien, in congue quam justo non dui.",
        CourseLessons: "2 Lessons",
        CourseDuration: "4h 30m",
        CourseRating: "4.8"
    }
];

var courseId = 0;

window.onload = () => {

    courseId = JSON.parse(localStorage.getItem('enroll'));

    document.getElementById('ordersummery').innerHTML = `
  
<div class="checkout-box flex-column justify-content-center align-items-center">
<h5 class="checout-account-heading">Course Summary</h5>
<div class="mt-lg-3">
    <div class="d-flex justify-content-center align-items-center gap-5">
        <h6 class="checout-account-subheading">${courses[courseId].CourseName}</h6>
    </div>
    <div class="d-flex justify-content-between align-items-center gap-5 mt-3">
        <h6 class="checout-account-subheading">Total:</h6>
        <h6 class="checout-account-subheading">${courses[courseId].CoursePrice}</h6>
    </div>
</div>
</div>
`
}


var checkout = document.getElementById('checkoutsubmit');

checkout.addEventListener('click', () => {

    var currentuser = localStorage.getItem('currentuser') || {};

    var first_name = document.getElementById('namef-checkout').value;
    var last_name = document.getElementById('namel-checkout').value;
    var number = document.getElementById('cnumber-checkout').value;
    var email = document.getElementById('cemail-checkout').value;
    var card_number = document.getElementById('cardnumber-checkout').value;
    var cvv_number = document.getElementById('cardcvvnumber-checkout').value;

    var checkoutDetails = {

        firstName: first_name,
        lastName: last_name,
        number: number,
        email: email,
        cardNumber: card_number,
        cvvNumber: cvv_number,
        buycourse: courseId
    }

    localStorage.setItem('checkoutDetails', JSON.stringify(checkoutDetails));

    var currentuser = localStorage.getItem('currentuser') || {};


    if (Object.keys(currentuser).length === 0) {

        document.getElementById('autocall').click();

    } else {

        window.location.href = 'courseDashBoard.html';
    }
})


